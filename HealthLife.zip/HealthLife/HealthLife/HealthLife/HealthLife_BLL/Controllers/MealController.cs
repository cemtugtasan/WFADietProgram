﻿using HealthLife_DAL.Entities;
using HealthLife_Model.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthLife_BLL.Controllers
{
    public class MealController
    {
        private static HealthLifeEntity _context = new HealthLifeEntity();

        public static void AddMealbyUser(Meal meal)
        {
            _context.Meals.Add(meal);
            _context.SaveChanges();
        }

        public static void RemoveMeal(Meal meal )
        {
            _context.Meals.Remove(meal);
            _context.SaveChanges();
        }
        public static void UpdateMeal(Meal meal)
        {
            _context.Meals.Attach(meal);
            _context.Entry(meal).State = EntityState.Modified;
            _context.SaveChanges();
        } 
        public static List<Meal> GetMeals() 
        {                      
            return _context.Meals.Where(x => x.UserId == UserController.LoginedUserID).ToList();
        }
        public static Meal GetMealByID(int mealID)
        {
            return _context.Meals.FirstOrDefault(x => x.Id == mealID);
        }
        public static List<MealProduct> GetMealProducts(int mealID) 
        {
            return _context.MealProducts.Where(x => x.MealId == mealID).ToList();
        }
        public static List<MealProduct> GetMealProductsWithCalories()
        {
            return _context.MealProducts.Include(x => x.Product).ToList();
        }
        public static void UpdateMealProduct(MealProduct mealProduct)
        {
            _context.MealProducts.Attach(mealProduct);
            _context.Entry(mealProduct).State = EntityState.Modified;
            _context.SaveChanges();
        }
        public static void DeleteProductFromMeal(MealProduct mealProduct)
        {
            _context.MealProducts.Remove(mealProduct);
            _context.SaveChanges();
        }
    }
}

