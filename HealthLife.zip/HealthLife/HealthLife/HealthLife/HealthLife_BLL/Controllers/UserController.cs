﻿using HealthLife_DAL.Entities;
using HealthLife_Model.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using XSystem.Security.Cryptography;

namespace HealthLife_BLL.Controllers
{
    public static class UserController
    {
        private static HealthLifeEntity _context = new HealthLifeEntity();
        public static int LoginedUserID { get; set; } = 0;

        public static void AddUser(User user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
        }

        public static void RemoveUser(User user)
        {
            _context.Users.Remove(user);
            _context.SaveChanges();
        }
        public static void UpdateUser(User user)
        {
            _context.Users.Attach(user);
            _context.Entry(user).State = EntityState.Modified;
            _context.SaveChanges();
        }
        public static bool CheckPassword(string userPassword)
        {
            int uppercaseCount = userPassword.Count(c => char.IsUpper(c));
            int lowercaseCount = userPassword.Count(c => char.IsLower(c));
            int SpecialCharCount = userPassword.Count(c=> char.IsPunctuation(c));
            if (userPassword.Length >= 8 && uppercaseCount>=2 && lowercaseCount>=2&&SpecialCharCount>=1)
            {
                return true;
            }
            return false;
        }
        public static bool IsValidEmail(string email)
        {
            try
            {
                var mail = new System.Net.Mail.MailAddress(email);
                return mail.Address == email;
            }
            catch (Exception)
            {
                return false;
                
            }
        }
        public static bool CheckLoginUser(string email,string password)
        {
            if (_context.Users.FirstOrDefault(x=>x.Mail==email && x.Password==password)!=null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static int GetUserID(string mail,string password)
        {
            User user = _context.Users.SingleOrDefault(x => x.Mail == mail && x.Password == password);
            if (user == null)
            {
                return -1;
            }
            
            return user.Id;
        }
        public static User GetUserByUserID(int userID)
        {
            return _context.Users.SingleOrDefault(x => x.Id == userID);
        }
        public static void DeleteUser(User user)
        {
            _context.Users.Remove(user);
            _context.SaveChanges();
        }
    }
}
