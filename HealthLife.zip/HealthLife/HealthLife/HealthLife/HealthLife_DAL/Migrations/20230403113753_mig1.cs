﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace HealthLife_DAL.Migrations
{
    /// <inheritdoc />
    public partial class mig1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Mail = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Height = table.Column<double>(type: "float", nullable: true),
                    Weight = table.Column<double>(type: "float", nullable: true),
                    Photo = table.Column<byte[]>(type: "varbinary(max)", nullable: true),
                    City = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Products",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UnitCalorie = table.Column<double>(type: "float", nullable: false),
                    Photo = table.Column<byte[]>(type: "varbinary(max)", nullable: true),
                    CategoryId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Products", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Products_Categories_CategoryId",
                        column: x => x.CategoryId,
                        principalTable: "Categories",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Meals",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UserId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Meals", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Meals_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "MealProducts",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PortionAmount = table.Column<double>(type: "float", nullable: false),
                    ProductId = table.Column<int>(type: "int", nullable: false),
                    MealId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MealProducts", x => x.Id);
                    table.ForeignKey(
                        name: "FK_MealProducts_Meals_MealId",
                        column: x => x.MealId,
                        principalTable: "Meals",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_MealProducts_Products_ProductId",
                        column: x => x.ProductId,
                        principalTable: "Products",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { 1, "Vegetables" },
                    { 2, "Meats" },
                    { 3, "Sea Foods" },
                    { 4, "Snacks" },
                    { 5, "Fruits" },
                    { 6, "Alcohols" },
                    { 7, "Soft Drinks" },
                    { 8, "Dairy Products" },
                    { 9, "Desserts" },
                    { 10, "Legumes" }
                });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "Id", "CategoryId", "Name", "Photo", "UnitCalorie" },
                values: new object[,]
                {
                    { 1, 5, "Apple", null, 52.0 },
                    { 2, 5, "Watermelon", null, 30.399999999999999 },
                    { 3, 5, "Banana", null, 88.700000000000003 },
                    { 4, 5, "Strawberry", null, 32.0 },
                    { 5, 5, "Plum", null, 45.899999999999999 },
                    { 6, 2, "Veal", null, 172.0 },
                    { 7, 2, "Chicken", null, 239.0 },
                    { 8, 2, "Pork", null, 242.0 },
                    { 9, 2, "Sausage", null, 300.0 },
                    { 10, 2, "Bacon", null, 540.0 },
                    { 11, 1, "Leek", null, 60.899999999999999 },
                    { 12, 1, "Spinach", null, 23.199999999999999 },
                    { 13, 1, "Lettuce", null, 14.800000000000001 },
                    { 14, 1, "Cauliflower", null, 24.899999999999999 },
                    { 15, 1, "Potato", null, 87.0 },
                    { 16, 3, "Shrimp", null, 99.0 },
                    { 17, 3, "Squid", null, 174.90000000000001 },
                    { 18, 3, "Octopus", null, 163.0 },
                    { 19, 4, "Chocolate", null, 545.0 },
                    { 20, 4, "Chips", null, 536.0 },
                    { 21, 4, "Nuts", null, 606.79999999999995 },
                    { 22, 4, "Biscuit", null, 353.0 },
                    { 23, 4, "Jelly Bean", null, 374.0 },
                    { 24, 6, "Beer", null, 43.0 },
                    { 25, 6, "Vodka", null, 231.0 },
                    { 26, 6, "Wine", null, 82.900000000000006 },
                    { 27, 6, "Whiskey", null, 250.0 },
                    { 28, 6, "Tequila", null, 231.0 },
                    { 29, 7, "Cola", null, 37.0 },
                    { 30, 7, "Ayran", null, 25.0 },
                    { 31, 7, "Soda", null, 95.0 },
                    { 32, 7, "Lemonade", null, 40.0 },
                    { 33, 7, "Sparkling Water", null, 0.0 },
                    { 34, 8, "Milk", null, 42.299999999999997 },
                    { 35, 8, "Yogurt", null, 58.799999999999997 },
                    { 36, 8, "Cheese", null, 402.0 },
                    { 37, 8, "Cream Cheese", null, 442.0 },
                    { 38, 8, "Cheddar", null, 402.5 },
                    { 39, 9, "Chocolate Cake", null, 370.69999999999999 },
                    { 40, 9, "Cheese Cake", null, 321.0 },
                    { 41, 9, "Pudding", null, 119.5 },
                    { 42, 9, "Baklava", null, 451.0 },
                    { 43, 9, "Künefe", null, 315.0 },
                    { 44, 9, "Magnolia", null, 42.0 },
                    { 45, 10, "Rice", null, 130.0 },
                    { 46, 10, "Beans", null, 347.0 },
                    { 47, 10, "Chickpeas", null, 364.0 },
                    { 48, 10, "Lentils", null, 116.0 },
                    { 49, 10, "Peas", null, 81.0 },
                    { 50, 10, "Black beans", null, 91.0 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_MealProducts_MealId",
                table: "MealProducts",
                column: "MealId");

            migrationBuilder.CreateIndex(
                name: "IX_MealProducts_ProductId",
                table: "MealProducts",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_Meals_UserId",
                table: "Meals",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_Products_CategoryId",
                table: "Products",
                column: "CategoryId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MealProducts");

            migrationBuilder.DropTable(
                name: "Meals");

            migrationBuilder.DropTable(
                name: "Products");

            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropTable(
                name: "Categories");
        }
    }
}
