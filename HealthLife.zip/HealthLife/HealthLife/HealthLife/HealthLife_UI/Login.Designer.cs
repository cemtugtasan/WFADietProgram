﻿namespace HealthLife_UI
{
    partial class Login
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuGradientPanel1 = new Bunifu.UI.WinForms.BunifuGradientPanel();
            this.bunifuPictureBox1 = new Bunifu.UI.WinForms.BunifuPictureBox();
            this.btnExit = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnRegisterLogin = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnLogin = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuLabel2 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.txtPasswordLogin = new Bunifu.UI.WinForms.BunifuTextBox();
            this.txtEMailLogin = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 10;
            this.bunifuElipse1.TargetControl = this;
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.BorderRadius = 1;
            this.bunifuGradientPanel1.Controls.Add(this.bunifuPictureBox1);
            this.bunifuGradientPanel1.Controls.Add(this.btnExit);
            this.bunifuGradientPanel1.Controls.Add(this.btnRegisterLogin);
            this.bunifuGradientPanel1.Controls.Add(this.btnLogin);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel2);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel1);
            this.bunifuGradientPanel1.Controls.Add(this.txtPasswordLogin);
            this.bunifuGradientPanel1.Controls.Add(this.txtEMailLogin);
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(92)))), ((int)(((byte)(188)))));
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.DeepPink;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.DodgerBlue;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(-3, -5);
            this.bunifuGradientPanel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1383, 1080);
            this.bunifuGradientPanel1.TabIndex = 0;
            this.bunifuGradientPanel1.Click += new System.EventHandler(this.bunifuGradientPanel1_Click);
            // 
            // bunifuPictureBox1
            // 
            this.bunifuPictureBox1.AllowFocused = false;
            this.bunifuPictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuPictureBox1.AutoSizeHeight = true;
            this.bunifuPictureBox1.BorderRadius = 0;
            this.bunifuPictureBox1.Image = global::HealthLife_UI.Properties.Resources.Company_logo_21;
            this.bunifuPictureBox1.IsCircle = false;
            this.bunifuPictureBox1.Location = new System.Drawing.Point(487, 27);
            this.bunifuPictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuPictureBox1.Name = "bunifuPictureBox1";
            this.bunifuPictureBox1.Size = new System.Drawing.Size(413, 413);
            this.bunifuPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuPictureBox1.TabIndex = 4;
            this.bunifuPictureBox1.TabStop = false;
            this.bunifuPictureBox1.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Square;
            // 
            // btnExit
            // 
            this.btnExit.ActiveBorderThickness = 1;
            this.btnExit.ActiveCornerRadius = 20;
            this.btnExit.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnExit.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnExit.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnExit.BackColor = System.Drawing.Color.Transparent;
            this.btnExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnExit.BackgroundImage")));
            this.btnExit.ButtonText = "Exit";
            this.btnExit.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnExit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnExit.IdleBorderThickness = 2;
            this.btnExit.IdleCornerRadius = 20;
            this.btnExit.IdleFillColor = System.Drawing.Color.DarkTurquoise;
            this.btnExit.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnExit.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnExit.Location = new System.Drawing.Point(1160, 977);
            this.btnExit.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(189, 76);
            this.btnExit.TabIndex = 2;
            this.btnExit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnRegisterLogin
            // 
            this.btnRegisterLogin.ActiveBorderThickness = 1;
            this.btnRegisterLogin.ActiveCornerRadius = 20;
            this.btnRegisterLogin.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnRegisterLogin.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnRegisterLogin.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnRegisterLogin.BackColor = System.Drawing.Color.Transparent;
            this.btnRegisterLogin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnRegisterLogin.BackgroundImage")));
            this.btnRegisterLogin.ButtonText = "Register";
            this.btnRegisterLogin.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnRegisterLogin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnRegisterLogin.IdleBorderThickness = 2;
            this.btnRegisterLogin.IdleCornerRadius = 20;
            this.btnRegisterLogin.IdleFillColor = System.Drawing.Color.DarkTurquoise;
            this.btnRegisterLogin.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnRegisterLogin.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnRegisterLogin.Location = new System.Drawing.Point(670, 669);
            this.btnRegisterLogin.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.btnRegisterLogin.Name = "btnRegisterLogin";
            this.btnRegisterLogin.Size = new System.Drawing.Size(189, 76);
            this.btnRegisterLogin.TabIndex = 4;
            this.btnRegisterLogin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnRegisterLogin.Click += new System.EventHandler(this.btnRegisterLogin_Click);
            // 
            // btnLogin
            // 
            this.btnLogin.ActiveBorderThickness = 1;
            this.btnLogin.ActiveCornerRadius = 20;
            this.btnLogin.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnLogin.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnLogin.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnLogin.BackColor = System.Drawing.Color.Transparent;
            this.btnLogin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLogin.BackgroundImage")));
            this.btnLogin.ButtonText = "Login";
            this.btnLogin.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnLogin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnLogin.IdleBorderThickness = 2;
            this.btnLogin.IdleCornerRadius = 20;
            this.btnLogin.IdleFillColor = System.Drawing.Color.DarkTurquoise;
            this.btnLogin.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnLogin.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnLogin.Location = new System.Drawing.Point(470, 669);
            this.btnLogin.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(189, 76);
            this.btnLogin.TabIndex = 3;
            this.btnLogin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // bunifuLabel2
            // 
            this.bunifuLabel2.AllowParentOverrides = false;
            this.bunifuLabel2.AutoEllipsis = false;
            this.bunifuLabel2.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel2.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel2.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel2.Location = new System.Drawing.Point(431, 612);
            this.bunifuLabel2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuLabel2.Name = "bunifuLabel2";
            this.bunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel2.Size = new System.Drawing.Size(101, 31);
            this.bunifuLabel2.TabIndex = 0;
            this.bunifuLabel2.Text = "Password";
            this.bunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel2.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AllowParentOverrides = false;
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel1.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel1.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel1.Location = new System.Drawing.Point(431, 537);
            this.bunifuLabel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(69, 31);
            this.bunifuLabel1.TabIndex = 0;
            this.bunifuLabel1.Text = "E-Mail";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // txtPasswordLogin
            // 
            this.txtPasswordLogin.AcceptsReturn = false;
            this.txtPasswordLogin.AcceptsTab = false;
            this.txtPasswordLogin.AnimationSpeed = 200;
            this.txtPasswordLogin.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtPasswordLogin.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtPasswordLogin.AutoSizeHeight = true;
            this.txtPasswordLogin.BackColor = System.Drawing.Color.Transparent;
            this.txtPasswordLogin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtPasswordLogin.BackgroundImage")));
            this.txtPasswordLogin.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtPasswordLogin.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtPasswordLogin.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtPasswordLogin.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtPasswordLogin.BorderRadius = 1;
            this.txtPasswordLogin.BorderThickness = 2;
            this.txtPasswordLogin.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.txtPasswordLogin.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtPasswordLogin.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtPasswordLogin.DefaultText = "";
            this.txtPasswordLogin.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.txtPasswordLogin.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.txtPasswordLogin.HideSelection = true;
            this.txtPasswordLogin.IconLeft = null;
            this.txtPasswordLogin.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPasswordLogin.IconPadding = 10;
            this.txtPasswordLogin.IconRight = null;
            this.txtPasswordLogin.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPasswordLogin.Lines = new string[0];
            this.txtPasswordLogin.Location = new System.Drawing.Point(542, 596);
            this.txtPasswordLogin.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtPasswordLogin.MaxLength = 32767;
            this.txtPasswordLogin.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtPasswordLogin.Modified = false;
            this.txtPasswordLogin.Multiline = false;
            this.txtPasswordLogin.Name = "txtPasswordLogin";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtPasswordLogin.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtPasswordLogin.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtPasswordLogin.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            stateProperties4.ForeColor = System.Drawing.Color.DarkTurquoise;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtPasswordLogin.OnIdleState = stateProperties4;
            this.txtPasswordLogin.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtPasswordLogin.PasswordChar = '*';
            this.txtPasswordLogin.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtPasswordLogin.PlaceholderText = "Enter text";
            this.txtPasswordLogin.ReadOnly = false;
            this.txtPasswordLogin.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPasswordLogin.SelectedText = "";
            this.txtPasswordLogin.SelectionLength = 0;
            this.txtPasswordLogin.SelectionStart = 0;
            this.txtPasswordLogin.ShortcutsEnabled = true;
            this.txtPasswordLogin.Size = new System.Drawing.Size(317, 69);
            this.txtPasswordLogin.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtPasswordLogin.TabIndex = 2;
            this.txtPasswordLogin.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtPasswordLogin.TextMarginBottom = 0;
            this.txtPasswordLogin.TextMarginLeft = 3;
            this.txtPasswordLogin.TextMarginTop = 1;
            this.txtPasswordLogin.TextPlaceholder = "Enter text";
            this.txtPasswordLogin.UseSystemPasswordChar = false;
            this.txtPasswordLogin.WordWrap = true;
            // 
            // txtEMailLogin
            // 
            this.txtEMailLogin.AcceptsReturn = false;
            this.txtEMailLogin.AcceptsTab = false;
            this.txtEMailLogin.AnimationSpeed = 200;
            this.txtEMailLogin.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtEMailLogin.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtEMailLogin.AutoSizeHeight = true;
            this.txtEMailLogin.BackColor = System.Drawing.Color.Transparent;
            this.txtEMailLogin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtEMailLogin.BackgroundImage")));
            this.txtEMailLogin.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtEMailLogin.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtEMailLogin.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtEMailLogin.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtEMailLogin.BorderRadius = 1;
            this.txtEMailLogin.BorderThickness = 2;
            this.txtEMailLogin.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.txtEMailLogin.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtEMailLogin.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtEMailLogin.DefaultText = "";
            this.txtEMailLogin.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.txtEMailLogin.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.txtEMailLogin.HideSelection = true;
            this.txtEMailLogin.IconLeft = null;
            this.txtEMailLogin.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEMailLogin.IconPadding = 10;
            this.txtEMailLogin.IconRight = null;
            this.txtEMailLogin.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEMailLogin.Lines = new string[0];
            this.txtEMailLogin.Location = new System.Drawing.Point(542, 521);
            this.txtEMailLogin.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtEMailLogin.MaxLength = 32767;
            this.txtEMailLogin.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtEMailLogin.Modified = false;
            this.txtEMailLogin.Multiline = false;
            this.txtEMailLogin.Name = "txtEMailLogin";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtEMailLogin.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtEMailLogin.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtEMailLogin.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            stateProperties8.ForeColor = System.Drawing.Color.DarkTurquoise;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtEMailLogin.OnIdleState = stateProperties8;
            this.txtEMailLogin.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtEMailLogin.PasswordChar = '\0';
            this.txtEMailLogin.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtEMailLogin.PlaceholderText = "Enter text";
            this.txtEMailLogin.ReadOnly = false;
            this.txtEMailLogin.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtEMailLogin.SelectedText = "";
            this.txtEMailLogin.SelectionLength = 0;
            this.txtEMailLogin.SelectionStart = 0;
            this.txtEMailLogin.ShortcutsEnabled = true;
            this.txtEMailLogin.Size = new System.Drawing.Size(317, 69);
            this.txtEMailLogin.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtEMailLogin.TabIndex = 1;
            this.txtEMailLogin.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtEMailLogin.TextMarginBottom = 0;
            this.txtEMailLogin.TextMarginLeft = 3;
            this.txtEMailLogin.TextMarginTop = 1;
            this.txtEMailLogin.TextPlaceholder = "Enter text";
            this.txtEMailLogin.UseSystemPasswordChar = false;
            this.txtEMailLogin.WordWrap = true;
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1371, 1067);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuPictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel1;
        private Bunifu.Framework.UI.BunifuThinButton2 btnRegisterLogin;
        private Bunifu.Framework.UI.BunifuThinButton2 btnLogin;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel2;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuTextBox txtPasswordLogin;
        private Bunifu.UI.WinForms.BunifuTextBox txtEMailLogin;
        private Bunifu.Framework.UI.BunifuThinButton2 btnExit;
        private Bunifu.UI.WinForms.BunifuPictureBox bunifuPictureBox1;
    }
}