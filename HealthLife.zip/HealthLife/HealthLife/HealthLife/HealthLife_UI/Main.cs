﻿using HealthLife_Model.Models;
using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HealthLife_UI
{
    public partial class Main : Form
    {      
        public Main()
        {
            InitializeComponent();
            
        }

        private void btnAddMeal_Click(object sender, EventArgs e)
        {
            AddMeal addMeal = new AddMeal();
            addMeal.ShowDialog();
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            
        }

        private void btnUserInformation_Click(object sender, EventArgs e)
        {
            UserInformation userInformation = new UserInformation();
            userInformation.ShowDialog();
        }

        private void btnReports_Click(object sender, EventArgs e)
        {
            Reports reports = new Reports();
            reports.ShowDialog();
        }

        private void btnLogOutMain_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.ShowDialog();
            this.Close();  
        }

        private void bunifuIconButton1_Click(object sender, EventArgs e)
        {
            AddProduct addProduct = new AddProduct();
            addProduct.ShowDialog();
        }
    }
}
