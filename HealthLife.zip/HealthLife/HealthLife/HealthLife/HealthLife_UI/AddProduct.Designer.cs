﻿namespace HealthLife_UI
{
    partial class AddProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddProduct));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.pbProductAddProduct = new Bunifu.UI.WinForms.BunifuPictureBox();
            this.dgwProductsAddProduct = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.ddCategoryAddProduct = new Bunifu.UI.WinForms.BunifuDropdown();
            this.bunifuLabel8 = new Bunifu.UI.WinForms.BunifuLabel();
            this.btnDeleteProduct = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnUpdateProduct = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnAddProduct = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuLabel4 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.txtCaloryAddProduct = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuGradientPanel1 = new Bunifu.UI.WinForms.BunifuGradientPanel();
            this.btnAddPhoto = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnBackAddProduct = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuLabel2 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel3 = new Bunifu.UI.WinForms.BunifuLabel();
            this.txtNameAddProduct = new Bunifu.UI.WinForms.BunifuTextBox();
            this.txtPhotoPath = new Bunifu.UI.WinForms.BunifuTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbProductAddProduct)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgwProductsAddProduct)).BeginInit();
            this.bunifuGradientPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // pbProductAddProduct
            // 
            this.pbProductAddProduct.AllowFocused = false;
            this.pbProductAddProduct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pbProductAddProduct.AutoSizeHeight = true;
            this.pbProductAddProduct.BorderRadius = 114;
            this.pbProductAddProduct.Image = ((System.Drawing.Image)(resources.GetObject("pbProductAddProduct.Image")));
            this.pbProductAddProduct.IsCircle = true;
            this.pbProductAddProduct.Location = new System.Drawing.Point(866, 30);
            this.pbProductAddProduct.Name = "pbProductAddProduct";
            this.pbProductAddProduct.Size = new System.Drawing.Size(229, 229);
            this.pbProductAddProduct.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbProductAddProduct.TabIndex = 7;
            this.pbProductAddProduct.TabStop = false;
            this.pbProductAddProduct.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Circle;
            this.pbProductAddProduct.Visible = false;
            // 
            // dgwProductsAddProduct
            // 
            this.dgwProductsAddProduct.AllowCustomTheming = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.dgwProductsAddProduct.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgwProductsAddProduct.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgwProductsAddProduct.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(92)))), ((int)(((byte)(188)))));
            this.dgwProductsAddProduct.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgwProductsAddProduct.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgwProductsAddProduct.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgwProductsAddProduct.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgwProductsAddProduct.ColumnHeadersHeight = 40;
            this.dgwProductsAddProduct.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.dgwProductsAddProduct.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dgwProductsAddProduct.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dgwProductsAddProduct.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.dgwProductsAddProduct.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgwProductsAddProduct.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.dgwProductsAddProduct.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.dgwProductsAddProduct.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.dgwProductsAddProduct.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dgwProductsAddProduct.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dgwProductsAddProduct.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.dgwProductsAddProduct.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.dgwProductsAddProduct.CurrentTheme.Name = null;
            this.dgwProductsAddProduct.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgwProductsAddProduct.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dgwProductsAddProduct.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dgwProductsAddProduct.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.dgwProductsAddProduct.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgwProductsAddProduct.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgwProductsAddProduct.EnableHeadersVisualStyles = false;
            this.dgwProductsAddProduct.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.dgwProductsAddProduct.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.dgwProductsAddProduct.HeaderBgColor = System.Drawing.Color.Empty;
            this.dgwProductsAddProduct.HeaderForeColor = System.Drawing.Color.White;
            this.dgwProductsAddProduct.Location = new System.Drawing.Point(21, 294);
            this.dgwProductsAddProduct.Name = "dgwProductsAddProduct";
            this.dgwProductsAddProduct.RowHeadersVisible = false;
            this.dgwProductsAddProduct.RowTemplate.Height = 40;
            this.dgwProductsAddProduct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgwProductsAddProduct.Size = new System.Drawing.Size(1176, 444);
            this.dgwProductsAddProduct.TabIndex = 5;
            this.dgwProductsAddProduct.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            // 
            // ddCategoryAddProduct
            // 
            this.ddCategoryAddProduct.BackColor = System.Drawing.Color.Transparent;
            this.ddCategoryAddProduct.BackgroundColor = System.Drawing.Color.White;
            this.ddCategoryAddProduct.BorderColor = System.Drawing.Color.Silver;
            this.ddCategoryAddProduct.BorderRadius = 1;
            this.ddCategoryAddProduct.Color = System.Drawing.Color.Silver;
            this.ddCategoryAddProduct.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down;
            this.ddCategoryAddProduct.DisabledBackColor = System.Drawing.Color.DodgerBlue;
            this.ddCategoryAddProduct.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ddCategoryAddProduct.DisabledColor = System.Drawing.Color.DodgerBlue;
            this.ddCategoryAddProduct.DisabledForeColor = System.Drawing.Color.DodgerBlue;
            this.ddCategoryAddProduct.DisabledIndicatorColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.ddCategoryAddProduct.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ddCategoryAddProduct.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thin;
            this.ddCategoryAddProduct.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddCategoryAddProduct.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.ddCategoryAddProduct.FillDropDown = true;
            this.ddCategoryAddProduct.FillIndicator = false;
            this.ddCategoryAddProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ddCategoryAddProduct.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ddCategoryAddProduct.ForeColor = System.Drawing.Color.Black;
            this.ddCategoryAddProduct.FormattingEnabled = true;
            this.ddCategoryAddProduct.Icon = null;
            this.ddCategoryAddProduct.IndicatorAlignment = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.ddCategoryAddProduct.IndicatorColor = System.Drawing.Color.DarkGray;
            this.ddCategoryAddProduct.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.ddCategoryAddProduct.IndicatorThickness = 2;
            this.ddCategoryAddProduct.IsDropdownOpened = false;
            this.ddCategoryAddProduct.ItemBackColor = System.Drawing.Color.DodgerBlue;
            this.ddCategoryAddProduct.ItemBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.ddCategoryAddProduct.ItemForeColor = System.Drawing.Color.Black;
            this.ddCategoryAddProduct.ItemHeight = 26;
            this.ddCategoryAddProduct.ItemHighLightColor = System.Drawing.Color.DarkTurquoise;
            this.ddCategoryAddProduct.ItemHighLightForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.ddCategoryAddProduct.ItemTopMargin = 3;
            this.ddCategoryAddProduct.Location = new System.Drawing.Point(132, 78);
            this.ddCategoryAddProduct.Name = "ddCategoryAddProduct";
            this.ddCategoryAddProduct.Size = new System.Drawing.Size(319, 32);
            this.ddCategoryAddProduct.TabIndex = 4;
            this.ddCategoryAddProduct.Text = null;
            this.ddCategoryAddProduct.TextAlignment = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.ddCategoryAddProduct.TextLeftMargin = 5;
            // 
            // bunifuLabel8
            // 
            this.bunifuLabel8.AllowParentOverrides = false;
            this.bunifuLabel8.AutoEllipsis = false;
            this.bunifuLabel8.AutoSize = false;
            this.bunifuLabel8.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel8.Font = new System.Drawing.Font("Monotype Corsiva", 35F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel8.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel8.Location = new System.Drawing.Point(21, 16);
            this.bunifuLabel8.Name = "bunifuLabel8";
            this.bunifuLabel8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel8.Size = new System.Drawing.Size(244, 56);
            this.bunifuLabel8.TabIndex = 3;
            this.bunifuLabel8.Text = "Add Product";
            this.bunifuLabel8.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel8.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // btnDeleteProduct
            // 
            this.btnDeleteProduct.ActiveBorderThickness = 1;
            this.btnDeleteProduct.ActiveCornerRadius = 20;
            this.btnDeleteProduct.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnDeleteProduct.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnDeleteProduct.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnDeleteProduct.BackColor = System.Drawing.Color.Transparent;
            this.btnDeleteProduct.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDeleteProduct.BackgroundImage")));
            this.btnDeleteProduct.ButtonText = "Delete";
            this.btnDeleteProduct.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnDeleteProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnDeleteProduct.IdleBorderThickness = 2;
            this.btnDeleteProduct.IdleCornerRadius = 20;
            this.btnDeleteProduct.IdleFillColor = System.Drawing.Color.DarkTurquoise;
            this.btnDeleteProduct.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnDeleteProduct.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnDeleteProduct.Location = new System.Drawing.Point(560, 154);
            this.btnDeleteProduct.Margin = new System.Windows.Forms.Padding(5);
            this.btnDeleteProduct.Name = "btnDeleteProduct";
            this.btnDeleteProduct.Size = new System.Drawing.Size(165, 57);
            this.btnDeleteProduct.TabIndex = 2;
            this.btnDeleteProduct.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDeleteProduct.Click += new System.EventHandler(this.btnDeleteProduct_Click);
            // 
            // btnUpdateProduct
            // 
            this.btnUpdateProduct.ActiveBorderThickness = 1;
            this.btnUpdateProduct.ActiveCornerRadius = 20;
            this.btnUpdateProduct.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnUpdateProduct.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnUpdateProduct.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnUpdateProduct.BackColor = System.Drawing.Color.Transparent;
            this.btnUpdateProduct.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnUpdateProduct.BackgroundImage")));
            this.btnUpdateProduct.ButtonText = "Update";
            this.btnUpdateProduct.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnUpdateProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnUpdateProduct.IdleBorderThickness = 2;
            this.btnUpdateProduct.IdleCornerRadius = 20;
            this.btnUpdateProduct.IdleFillColor = System.Drawing.Color.DarkTurquoise;
            this.btnUpdateProduct.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnUpdateProduct.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnUpdateProduct.Location = new System.Drawing.Point(560, 94);
            this.btnUpdateProduct.Margin = new System.Windows.Forms.Padding(5);
            this.btnUpdateProduct.Name = "btnUpdateProduct";
            this.btnUpdateProduct.Size = new System.Drawing.Size(165, 57);
            this.btnUpdateProduct.TabIndex = 2;
            this.btnUpdateProduct.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnUpdateProduct.Click += new System.EventHandler(this.btnUpdateProduct_Click);
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.ActiveBorderThickness = 1;
            this.btnAddProduct.ActiveCornerRadius = 20;
            this.btnAddProduct.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnAddProduct.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnAddProduct.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnAddProduct.BackColor = System.Drawing.Color.Transparent;
            this.btnAddProduct.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAddProduct.BackgroundImage")));
            this.btnAddProduct.ButtonText = "Add";
            this.btnAddProduct.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnAddProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnAddProduct.IdleBorderThickness = 2;
            this.btnAddProduct.IdleCornerRadius = 20;
            this.btnAddProduct.IdleFillColor = System.Drawing.Color.DarkTurquoise;
            this.btnAddProduct.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnAddProduct.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnAddProduct.Location = new System.Drawing.Point(560, 31);
            this.btnAddProduct.Margin = new System.Windows.Forms.Padding(5);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(165, 57);
            this.btnAddProduct.TabIndex = 2;
            this.btnAddProduct.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // bunifuLabel4
            // 
            this.bunifuLabel4.AllowParentOverrides = false;
            this.bunifuLabel4.AutoEllipsis = false;
            this.bunifuLabel4.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel4.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel4.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel4.Location = new System.Drawing.Point(45, 181);
            this.bunifuLabel4.Name = "bunifuLabel4";
            this.bunifuLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel4.Size = new System.Drawing.Size(57, 25);
            this.bunifuLabel4.TabIndex = 1;
            this.bunifuLabel4.Text = "Calory";
            this.bunifuLabel4.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel4.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AllowParentOverrides = false;
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel1.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel1.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel1.Location = new System.Drawing.Point(21, 78);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(81, 25);
            this.bunifuLabel1.TabIndex = 1;
            this.bunifuLabel1.Text = "Category";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // txtCaloryAddProduct
            // 
            this.txtCaloryAddProduct.AcceptsReturn = false;
            this.txtCaloryAddProduct.AcceptsTab = false;
            this.txtCaloryAddProduct.AnimationSpeed = 200;
            this.txtCaloryAddProduct.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtCaloryAddProduct.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtCaloryAddProduct.AutoSizeHeight = true;
            this.txtCaloryAddProduct.BackColor = System.Drawing.Color.Transparent;
            this.txtCaloryAddProduct.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtCaloryAddProduct.BackgroundImage")));
            this.txtCaloryAddProduct.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtCaloryAddProduct.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtCaloryAddProduct.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtCaloryAddProduct.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtCaloryAddProduct.BorderRadius = 1;
            this.txtCaloryAddProduct.BorderThickness = 2;
            this.txtCaloryAddProduct.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.txtCaloryAddProduct.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtCaloryAddProduct.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtCaloryAddProduct.DefaultText = "";
            this.txtCaloryAddProduct.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.txtCaloryAddProduct.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.txtCaloryAddProduct.HideSelection = true;
            this.txtCaloryAddProduct.IconLeft = null;
            this.txtCaloryAddProduct.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCaloryAddProduct.IconPadding = 10;
            this.txtCaloryAddProduct.IconRight = null;
            this.txtCaloryAddProduct.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCaloryAddProduct.Lines = new string[0];
            this.txtCaloryAddProduct.Location = new System.Drawing.Point(132, 170);
            this.txtCaloryAddProduct.MaxLength = 32767;
            this.txtCaloryAddProduct.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtCaloryAddProduct.Modified = false;
            this.txtCaloryAddProduct.Multiline = false;
            this.txtCaloryAddProduct.Name = "txtCaloryAddProduct";
            stateProperties9.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCaloryAddProduct.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtCaloryAddProduct.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCaloryAddProduct.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Silver;
            stateProperties12.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            stateProperties12.ForeColor = System.Drawing.Color.DarkTurquoise;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCaloryAddProduct.OnIdleState = stateProperties12;
            this.txtCaloryAddProduct.Padding = new System.Windows.Forms.Padding(3);
            this.txtCaloryAddProduct.PasswordChar = '\0';
            this.txtCaloryAddProduct.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtCaloryAddProduct.PlaceholderText = "Enter text";
            this.txtCaloryAddProduct.ReadOnly = false;
            this.txtCaloryAddProduct.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCaloryAddProduct.SelectedText = "";
            this.txtCaloryAddProduct.SelectionLength = 0;
            this.txtCaloryAddProduct.SelectionStart = 0;
            this.txtCaloryAddProduct.ShortcutsEnabled = true;
            this.txtCaloryAddProduct.Size = new System.Drawing.Size(319, 50);
            this.txtCaloryAddProduct.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtCaloryAddProduct.TabIndex = 0;
            this.txtCaloryAddProduct.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtCaloryAddProduct.TextMarginBottom = 0;
            this.txtCaloryAddProduct.TextMarginLeft = 3;
            this.txtCaloryAddProduct.TextMarginTop = 1;
            this.txtCaloryAddProduct.TextPlaceholder = "Enter text";
            this.txtCaloryAddProduct.UseSystemPasswordChar = false;
            this.txtCaloryAddProduct.WordWrap = true;
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.BorderRadius = 1;
            this.bunifuGradientPanel1.Controls.Add(this.pbProductAddProduct);
            this.bunifuGradientPanel1.Controls.Add(this.dgwProductsAddProduct);
            this.bunifuGradientPanel1.Controls.Add(this.ddCategoryAddProduct);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel8);
            this.bunifuGradientPanel1.Controls.Add(this.btnAddPhoto);
            this.bunifuGradientPanel1.Controls.Add(this.btnDeleteProduct);
            this.bunifuGradientPanel1.Controls.Add(this.btnBackAddProduct);
            this.bunifuGradientPanel1.Controls.Add(this.btnUpdateProduct);
            this.bunifuGradientPanel1.Controls.Add(this.btnAddProduct);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel2);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel3);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel4);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel1);
            this.bunifuGradientPanel1.Controls.Add(this.txtNameAddProduct);
            this.bunifuGradientPanel1.Controls.Add(this.txtPhotoPath);
            this.bunifuGradientPanel1.Controls.Add(this.txtCaloryAddProduct);
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(92)))), ((int)(((byte)(188)))));
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.DeepPink;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.DodgerBlue;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(-4, -4);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1208, 807);
            this.bunifuGradientPanel1.TabIndex = 3;
            // 
            // btnAddPhoto
            // 
            this.btnAddPhoto.ActiveBorderThickness = 1;
            this.btnAddPhoto.ActiveCornerRadius = 20;
            this.btnAddPhoto.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnAddPhoto.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnAddPhoto.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnAddPhoto.BackColor = System.Drawing.Color.Transparent;
            this.btnAddPhoto.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAddPhoto.BackgroundImage")));
            this.btnAddPhoto.ButtonText = "Add Photo";
            this.btnAddPhoto.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnAddPhoto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnAddPhoto.IdleBorderThickness = 2;
            this.btnAddPhoto.IdleCornerRadius = 20;
            this.btnAddPhoto.IdleFillColor = System.Drawing.Color.DarkTurquoise;
            this.btnAddPhoto.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnAddPhoto.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnAddPhoto.Location = new System.Drawing.Point(560, 219);
            this.btnAddPhoto.Margin = new System.Windows.Forms.Padding(5);
            this.btnAddPhoto.Name = "btnAddPhoto";
            this.btnAddPhoto.Size = new System.Drawing.Size(165, 57);
            this.btnAddPhoto.TabIndex = 2;
            this.btnAddPhoto.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAddPhoto.Click += new System.EventHandler(this.btnAddPhoto_Click);
            // 
            // btnBackAddProduct
            // 
            this.btnBackAddProduct.ActiveBorderThickness = 1;
            this.btnBackAddProduct.ActiveCornerRadius = 20;
            this.btnBackAddProduct.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnBackAddProduct.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnBackAddProduct.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnBackAddProduct.BackColor = System.Drawing.Color.Transparent;
            this.btnBackAddProduct.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBackAddProduct.BackgroundImage")));
            this.btnBackAddProduct.ButtonText = "Back";
            this.btnBackAddProduct.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnBackAddProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnBackAddProduct.IdleBorderThickness = 2;
            this.btnBackAddProduct.IdleCornerRadius = 20;
            this.btnBackAddProduct.IdleFillColor = System.Drawing.Color.DarkTurquoise;
            this.btnBackAddProduct.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnBackAddProduct.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnBackAddProduct.Location = new System.Drawing.Point(1032, 746);
            this.btnBackAddProduct.Margin = new System.Windows.Forms.Padding(5);
            this.btnBackAddProduct.Name = "btnBackAddProduct";
            this.btnBackAddProduct.Size = new System.Drawing.Size(165, 57);
            this.btnBackAddProduct.TabIndex = 2;
            this.btnBackAddProduct.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnBackAddProduct.Click += new System.EventHandler(this.btnBackAddProduct_Click);
            // 
            // bunifuLabel2
            // 
            this.bunifuLabel2.AllowParentOverrides = false;
            this.bunifuLabel2.AutoEllipsis = false;
            this.bunifuLabel2.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel2.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel2.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel2.Location = new System.Drawing.Point(45, 128);
            this.bunifuLabel2.Name = "bunifuLabel2";
            this.bunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel2.Size = new System.Drawing.Size(52, 25);
            this.bunifuLabel2.TabIndex = 1;
            this.bunifuLabel2.Text = "Name";
            this.bunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel2.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel3
            // 
            this.bunifuLabel3.AllowParentOverrides = false;
            this.bunifuLabel3.AutoEllipsis = false;
            this.bunifuLabel3.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel3.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel3.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel3.Location = new System.Drawing.Point(45, 237);
            this.bunifuLabel3.Name = "bunifuLabel3";
            this.bunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel3.Size = new System.Drawing.Size(54, 25);
            this.bunifuLabel3.TabIndex = 1;
            this.bunifuLabel3.Text = "Photo";
            this.bunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel3.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // txtNameAddProduct
            // 
            this.txtNameAddProduct.AcceptsReturn = false;
            this.txtNameAddProduct.AcceptsTab = false;
            this.txtNameAddProduct.AnimationSpeed = 200;
            this.txtNameAddProduct.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtNameAddProduct.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtNameAddProduct.AutoSizeHeight = true;
            this.txtNameAddProduct.BackColor = System.Drawing.Color.Transparent;
            this.txtNameAddProduct.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtNameAddProduct.BackgroundImage")));
            this.txtNameAddProduct.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtNameAddProduct.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtNameAddProduct.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtNameAddProduct.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtNameAddProduct.BorderRadius = 1;
            this.txtNameAddProduct.BorderThickness = 2;
            this.txtNameAddProduct.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.txtNameAddProduct.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtNameAddProduct.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtNameAddProduct.DefaultText = "";
            this.txtNameAddProduct.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.txtNameAddProduct.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.txtNameAddProduct.HideSelection = true;
            this.txtNameAddProduct.IconLeft = null;
            this.txtNameAddProduct.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNameAddProduct.IconPadding = 10;
            this.txtNameAddProduct.IconRight = null;
            this.txtNameAddProduct.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNameAddProduct.Lines = new string[0];
            this.txtNameAddProduct.Location = new System.Drawing.Point(132, 116);
            this.txtNameAddProduct.MaxLength = 32767;
            this.txtNameAddProduct.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtNameAddProduct.Modified = false;
            this.txtNameAddProduct.Multiline = false;
            this.txtNameAddProduct.Name = "txtNameAddProduct";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNameAddProduct.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtNameAddProduct.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNameAddProduct.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            stateProperties4.ForeColor = System.Drawing.Color.DarkTurquoise;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNameAddProduct.OnIdleState = stateProperties4;
            this.txtNameAddProduct.Padding = new System.Windows.Forms.Padding(3);
            this.txtNameAddProduct.PasswordChar = '\0';
            this.txtNameAddProduct.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtNameAddProduct.PlaceholderText = "Enter text";
            this.txtNameAddProduct.ReadOnly = false;
            this.txtNameAddProduct.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtNameAddProduct.SelectedText = "";
            this.txtNameAddProduct.SelectionLength = 0;
            this.txtNameAddProduct.SelectionStart = 0;
            this.txtNameAddProduct.ShortcutsEnabled = true;
            this.txtNameAddProduct.Size = new System.Drawing.Size(319, 50);
            this.txtNameAddProduct.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtNameAddProduct.TabIndex = 0;
            this.txtNameAddProduct.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtNameAddProduct.TextMarginBottom = 0;
            this.txtNameAddProduct.TextMarginLeft = 3;
            this.txtNameAddProduct.TextMarginTop = 1;
            this.txtNameAddProduct.TextPlaceholder = "Enter text";
            this.txtNameAddProduct.UseSystemPasswordChar = false;
            this.txtNameAddProduct.WordWrap = true;
            // 
            // txtPhotoPath
            // 
            this.txtPhotoPath.AcceptsReturn = false;
            this.txtPhotoPath.AcceptsTab = false;
            this.txtPhotoPath.AnimationSpeed = 200;
            this.txtPhotoPath.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtPhotoPath.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtPhotoPath.AutoSizeHeight = true;
            this.txtPhotoPath.BackColor = System.Drawing.Color.Transparent;
            this.txtPhotoPath.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtPhotoPath.BackgroundImage")));
            this.txtPhotoPath.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtPhotoPath.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtPhotoPath.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtPhotoPath.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtPhotoPath.BorderRadius = 1;
            this.txtPhotoPath.BorderThickness = 2;
            this.txtPhotoPath.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.txtPhotoPath.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtPhotoPath.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtPhotoPath.DefaultText = "";
            this.txtPhotoPath.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.txtPhotoPath.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.txtPhotoPath.HideSelection = true;
            this.txtPhotoPath.IconLeft = null;
            this.txtPhotoPath.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPhotoPath.IconPadding = 10;
            this.txtPhotoPath.IconRight = null;
            this.txtPhotoPath.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPhotoPath.Lines = new string[0];
            this.txtPhotoPath.Location = new System.Drawing.Point(132, 226);
            this.txtPhotoPath.MaxLength = 32767;
            this.txtPhotoPath.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtPhotoPath.Modified = false;
            this.txtPhotoPath.Multiline = false;
            this.txtPhotoPath.Name = "txtPhotoPath";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtPhotoPath.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtPhotoPath.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtPhotoPath.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            stateProperties8.ForeColor = System.Drawing.Color.DarkTurquoise;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtPhotoPath.OnIdleState = stateProperties8;
            this.txtPhotoPath.Padding = new System.Windows.Forms.Padding(3);
            this.txtPhotoPath.PasswordChar = '\0';
            this.txtPhotoPath.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtPhotoPath.PlaceholderText = "Enter text";
            this.txtPhotoPath.ReadOnly = false;
            this.txtPhotoPath.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPhotoPath.SelectedText = "";
            this.txtPhotoPath.SelectionLength = 0;
            this.txtPhotoPath.SelectionStart = 0;
            this.txtPhotoPath.ShortcutsEnabled = true;
            this.txtPhotoPath.Size = new System.Drawing.Size(319, 50);
            this.txtPhotoPath.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtPhotoPath.TabIndex = 0;
            this.txtPhotoPath.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtPhotoPath.TextMarginBottom = 0;
            this.txtPhotoPath.TextMarginLeft = 3;
            this.txtPhotoPath.TextMarginTop = 1;
            this.txtPhotoPath.TextPlaceholder = "Enter text";
            this.txtPhotoPath.UseSystemPasswordChar = false;
            this.txtPhotoPath.WordWrap = true;
            // 
            // AddProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 800);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddProduct";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddProduct";
            this.Load += new System.EventHandler(this.AddProduct_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbProductAddProduct)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgwProductsAddProduct)).EndInit();
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel1;
        private Bunifu.UI.WinForms.BunifuPictureBox pbProductAddProduct;
        private Bunifu.UI.WinForms.BunifuDataGridView dgwProductsAddProduct;
        private Bunifu.UI.WinForms.BunifuDropdown ddCategoryAddProduct;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel8;
        private Bunifu.Framework.UI.BunifuThinButton2 btnAddPhoto;
        private Bunifu.Framework.UI.BunifuThinButton2 btnDeleteProduct;
        private Bunifu.Framework.UI.BunifuThinButton2 btnBackAddProduct;
        private Bunifu.Framework.UI.BunifuThinButton2 btnUpdateProduct;
        private Bunifu.Framework.UI.BunifuThinButton2 btnAddProduct;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel4;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuTextBox txtCaloryAddProduct;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel2;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel3;
        private Bunifu.UI.WinForms.BunifuTextBox txtNameAddProduct;
        private Bunifu.UI.WinForms.BunifuTextBox txtPhotoPath;
    }
}