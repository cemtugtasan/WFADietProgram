﻿namespace HealthLife_UI
{
    partial class Reports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Reports));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuGradientPanel1 = new Bunifu.UI.WinForms.BunifuGradientPanel();
            this.btnBackReports = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuLabel5 = new Bunifu.UI.WinForms.BunifuLabel();
            this.ddReportType = new Bunifu.UI.WinForms.BunifuDropdown();
            this.dgvDailyReport = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.bunifuLabel3 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDailyReport)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.BorderRadius = 1;
            this.bunifuGradientPanel1.Controls.Add(this.btnBackReports);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel5);
            this.bunifuGradientPanel1.Controls.Add(this.ddReportType);
            this.bunifuGradientPanel1.Controls.Add(this.dgvDailyReport);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel3);
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(92)))), ((int)(((byte)(188)))));
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.DeepPink;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.DodgerBlue;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(-2, -8);
            this.bunifuGradientPanel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1378, 1081);
            this.bunifuGradientPanel1.TabIndex = 2;
            // 
            // btnBackReports
            // 
            this.btnBackReports.ActiveBorderThickness = 1;
            this.btnBackReports.ActiveCornerRadius = 20;
            this.btnBackReports.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnBackReports.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnBackReports.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnBackReports.BackColor = System.Drawing.Color.Transparent;
            this.btnBackReports.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBackReports.BackgroundImage")));
            this.btnBackReports.ButtonText = "Back";
            this.btnBackReports.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnBackReports.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnBackReports.IdleBorderThickness = 2;
            this.btnBackReports.IdleCornerRadius = 20;
            this.btnBackReports.IdleFillColor = System.Drawing.Color.DarkTurquoise;
            this.btnBackReports.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnBackReports.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnBackReports.Location = new System.Drawing.Point(653, 7);
            this.btnBackReports.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.btnBackReports.Name = "btnBackReports";
            this.btnBackReports.Size = new System.Drawing.Size(189, 76);
            this.btnBackReports.TabIndex = 4;
            this.btnBackReports.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnBackReports.Click += new System.EventHandler(this.btnBackReports_Click);
            // 
            // bunifuLabel5
            // 
            this.bunifuLabel5.AllowParentOverrides = false;
            this.bunifuLabel5.AutoEllipsis = false;
            this.bunifuLabel5.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel5.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel5.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel5.Location = new System.Drawing.Point(850, 24);
            this.bunifuLabel5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuLabel5.Name = "bunifuLabel5";
            this.bunifuLabel5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel5.Size = new System.Drawing.Size(142, 31);
            this.bunifuLabel5.TabIndex = 8;
            this.bunifuLabel5.Text = "Report Type : ";
            this.bunifuLabel5.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel5.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // ddReportType
            // 
            this.ddReportType.BackColor = System.Drawing.Color.Transparent;
            this.ddReportType.BackgroundColor = System.Drawing.Color.White;
            this.ddReportType.BorderColor = System.Drawing.Color.Silver;
            this.ddReportType.BorderRadius = 1;
            this.ddReportType.Color = System.Drawing.Color.Silver;
            this.ddReportType.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down;
            this.ddReportType.DisabledBackColor = System.Drawing.Color.DodgerBlue;
            this.ddReportType.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ddReportType.DisabledColor = System.Drawing.Color.DodgerBlue;
            this.ddReportType.DisabledForeColor = System.Drawing.Color.DodgerBlue;
            this.ddReportType.DisabledIndicatorColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.ddReportType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ddReportType.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thin;
            this.ddReportType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddReportType.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.ddReportType.FillDropDown = true;
            this.ddReportType.FillIndicator = false;
            this.ddReportType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ddReportType.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ddReportType.ForeColor = System.Drawing.Color.Black;
            this.ddReportType.FormattingEnabled = true;
            this.ddReportType.Icon = null;
            this.ddReportType.IndicatorAlignment = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.ddReportType.IndicatorColor = System.Drawing.Color.DarkGray;
            this.ddReportType.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.ddReportType.IndicatorThickness = 2;
            this.ddReportType.IsDropdownOpened = false;
            this.ddReportType.ItemBackColor = System.Drawing.Color.DodgerBlue;
            this.ddReportType.ItemBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.ddReportType.ItemForeColor = System.Drawing.Color.Black;
            this.ddReportType.ItemHeight = 26;
            this.ddReportType.ItemHighLightColor = System.Drawing.Color.DarkTurquoise;
            this.ddReportType.ItemHighLightForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.ddReportType.Items.AddRange(new object[] {
            "End Of Day Report",
            "Weekly Benchmark Report",
            "Monthly Benchmark Report",
            "Food Type Report"});
            this.ddReportType.ItemTopMargin = 3;
            this.ddReportType.Location = new System.Drawing.Point(998, 24);
            this.ddReportType.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ddReportType.Name = "ddReportType";
            this.ddReportType.Size = new System.Drawing.Size(364, 32);
            this.ddReportType.TabIndex = 7;
            this.ddReportType.Text = null;
            this.ddReportType.TextAlignment = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.ddReportType.TextLeftMargin = 5;
            this.ddReportType.SelectedIndexChanged += new System.EventHandler(this.ddReportType_SelectedIndexChanged_1);
            // 
            // dgvDailyReport
            // 
            this.dgvDailyReport.AllowCustomTheming = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.dgvDailyReport.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvDailyReport.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDailyReport.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(92)))), ((int)(((byte)(188)))));
            this.dgvDailyReport.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvDailyReport.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvDailyReport.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDailyReport.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvDailyReport.ColumnHeadersHeight = 40;
            this.dgvDailyReport.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.dgvDailyReport.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dgvDailyReport.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvDailyReport.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.dgvDailyReport.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvDailyReport.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.dgvDailyReport.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.dgvDailyReport.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.dgvDailyReport.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dgvDailyReport.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dgvDailyReport.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.dgvDailyReport.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.dgvDailyReport.CurrentTheme.Name = null;
            this.dgvDailyReport.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvDailyReport.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dgvDailyReport.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvDailyReport.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.dgvDailyReport.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDailyReport.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvDailyReport.EnableHeadersVisualStyles = false;
            this.dgvDailyReport.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.dgvDailyReport.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.dgvDailyReport.HeaderBgColor = System.Drawing.Color.Empty;
            this.dgvDailyReport.HeaderForeColor = System.Drawing.Color.White;
            this.dgvDailyReport.Location = new System.Drawing.Point(11, 87);
            this.dgvDailyReport.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgvDailyReport.Name = "dgvDailyReport";
            this.dgvDailyReport.RowHeadersVisible = false;
            this.dgvDailyReport.RowHeadersWidth = 51;
            this.dgvDailyReport.RowTemplate.Height = 40;
            this.dgvDailyReport.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDailyReport.Size = new System.Drawing.Size(1351, 972);
            this.dgvDailyReport.TabIndex = 6;
            this.dgvDailyReport.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            // 
            // bunifuLabel3
            // 
            this.bunifuLabel3.AllowParentOverrides = false;
            this.bunifuLabel3.AutoEllipsis = false;
            this.bunifuLabel3.AutoSize = false;
            this.bunifuLabel3.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel3.Font = new System.Drawing.Font("Monotype Corsiva", 35F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel3.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel3.Location = new System.Drawing.Point(11, 4);
            this.bunifuLabel3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuLabel3.Name = "bunifuLabel3";
            this.bunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel3.Size = new System.Drawing.Size(342, 75);
            this.bunifuLabel3.TabIndex = 3;
            this.bunifuLabel3.Text = "Reports";
            this.bunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel3.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // Reports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1371, 1067);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Reports";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reports";
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDailyReport)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel1;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel3;
        private Bunifu.UI.WinForms.BunifuDataGridView dgvDailyReport;
        private Bunifu.UI.WinForms.BunifuDropdown ddReportType;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel5;
        private Bunifu.Framework.UI.BunifuThinButton2 btnBackReports;
    }
}