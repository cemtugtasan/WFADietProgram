﻿using HealthLife_BLL.Controllers;
using HealthLife_Model.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HealthLife_UI
{
    public partial class AddProduct : Form
    {
        public AddProduct()
        {
            InitializeComponent();
        }

        private void AddProduct_Load(object sender, EventArgs e)
        {
            Refresh();
        }



        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            Product product = new Product();
            if (product.Name != null && product.UnitCalorie != null && product.CategoryId != null)
            {
                product.Name = txtNameAddProduct.Text;
                product.UnitCalorie = Convert.ToDouble(txtCaloryAddProduct.Text);
                product.CategoryId = ddCategoryAddProduct.SelectedIndex + 1;

                var products = ProductController.GetProductName();
                if (ProductController.GetProductName().FirstOrDefault(x => x == product.Name) == null)
                {

                    if (product.Photo != null)
                    {
                        product.Photo = File.ReadAllBytes(txtPhotoPath.Text);
                    }
                    ProductController.AddProduct(product);
                    MessageBox.Show("You can use it now, but our control group will verify and approve the accuracy of the product you added.");
                    Refresh();
                }
                else
                {
                    MessageBox.Show("Your product is already added!");
                }
            }
            else
            {
                MessageBox.Show("Please fill all the information");
            }
        }


        private void btnUpdateProduct_Click(object sender, EventArgs e)
        {
            Product product = dgwProductsAddProduct.SelectedRows[0].DataBoundItem as Product;
            product.Name = txtNameAddProduct.Text;
            product.UnitCalorie = Convert.ToDouble(txtCaloryAddProduct.Text);
            product.CategoryId = ddCategoryAddProduct.SelectedIndex +1;        
            product.Photo = File.ReadAllBytes(txtPhotoPath.Text);
            
            ProductController.UpdateProduct(product);
            MessageBox.Show("You can use it now, but our control group will verify and approve the accuracy of the product you updated.");
            Refresh();

        }

        private void btnDeleteProduct_Click(object sender, EventArgs e)
        {
            Product product = dgwProductsAddProduct.SelectedRows[0].DataBoundItem as Product;
            ProductController.RemoveProduct(product);
            MessageBox.Show("Product deleted.");
            Refresh();

        }

        private void btnAddPhoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog= new OpenFileDialog();
            openFileDialog.ShowDialog();            
            txtPhotoPath.ReadOnly = true;
            txtPhotoPath.Text = openFileDialog.FileName;
            Refresh();

        }
        private void Refresh()
        {
            ddCategoryAddProduct.DataSource = CategoryController.GetCategories();
            ddCategoryAddProduct.DisplayMember = "Name";
            dgwProductsAddProduct.DataSource = ProductController.GetProducts();
        }

        private void btnBackAddProduct_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
