﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthLife_Model.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double UnitCalorie { get; set; }
        public byte[]? Photo { get; set; }
        public int CategoryId { get; set; }
        [Browsable(false)]
        public virtual Category Category { get; set; }
        [Browsable(false)]
        public virtual ICollection<MealProduct> MealProducts { get; } = new List<MealProduct>();
    }
}
