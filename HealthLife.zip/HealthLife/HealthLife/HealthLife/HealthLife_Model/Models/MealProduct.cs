﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthLife_Model.Models
{
    public class MealProduct
    {
        public int Id { get; set; }

        public double PortionAmount { get; set; }

        public int ProductId { get; set; }
        public int MealId { get; set; }
        [Browsable(false)]
        public virtual Product Product { get; set; }
        [Browsable(false)]
        public virtual Meal Meal { get; set; }

    }
}
